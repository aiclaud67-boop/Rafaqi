package com.rafiqi.app

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private lateinit var say: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tips = listOf(
        "اشرب كوب ماء 💧", "أرِح عينيك: انظر بعيدًا 20 ثانية 👀",
        "هل تريد استخدام واتساب الآن؟ 😉", "لا تُطِل التخطيط للسفر ✈️",
        "افرد ظهرك وخذ نفسًا عميقًا 🧘", "هل رتّبت مواعيد اليوم؟ 📅", "خذ استراحة قصيرة ☕"
    )

    override fun onBind(i: Intent?): IBinder? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "rf"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "رفيقي", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("رفيقي معك")
            .setSmallIcon(android.R.drawable.star_on).build())
        if (root == null) build()
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        say = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#241b3a")); visibility = View.GONE
            setPadding(dp(12), dp(8), dp(12), dp(8)); maxWidth = dp(220)
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat() }
        }
        val face = TextView(this).apply {
            text = "🐣"; textSize = 32f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.parseColor("#7c5cff")); shape = GradientDrawable.OVAL }
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(say); addView(face, LinearLayout.LayoutParams(dp(64), dp(64)))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(300) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        face.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) startActivity(
                    Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            true
        }
        wm.addView(root, lp)
        loop()
    }

    private fun loop() {
        h.postDelayed({
            say.text = tips.random(); say.visibility = View.VISIBLE
            h.postDelayed({ say.visibility = View.GONE }, 6000)
            loop()
        }, 40000)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); root?.let { wm.removeView(it) }; super.onDestroy() }
}
